
export default function Go_top(){
    return <a href="#">
        <h1 style={{
            color : '#fff', position : 'fixed',
            bottom : '5vmin', right : '5vmin',
            borderRadius : '50%', fontSize : '4.5vmin',
            padding : '0.5rem', background : '#181818'
        }}><i className="fa-solid fa-angles-up"></i></h1>
        </a>
}