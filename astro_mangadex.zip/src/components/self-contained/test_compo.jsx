export default function JSX_testeur(){
    return (
        <div className="testeur" style={{
            border : 'solid blue', width : '50vw', height : '70vh'
        }}>

        </div>
    )
}