import { ImageSmallDetails } from "../../self-contained/ImageSmallDetails"
import Loader_1 from "../../self-contained/load_test";

// function for displaying the suggestions from the api
export default function Results(props){
    let reultats = props.data

    // only render when we have result otherwise display loading animation
    if (reultats.length > 0){
        return (
            <>

        <section>
            <div style={{
                width : "96%", margin : "2% auto",
                display : 'flex', flexDirection : 'column', gap : '0.5em',
            }}>

            {reultats.map((serie, i) => {
                
                
                return (
                    <a href={"/serie/"+serie.id}>

                        <ImageSmallDetails
                        key={i}
                        serie={serie}
                        picWidth={3}
                        picMaxWidth={100}
                        picMinWidth={60}
                        picAspectRatio={[10, 16]}
                        rounded={1}
                        gap_between={true}
                        />
                    </a>
                    )
                    
                })}
            <a href="/see_all" id="voir_tout">
            <h3 style={{
                fontSize : '1.2em', margin : '1rem auto', textAlign : 'center', background : "var(--light-gray)", width : '50%',
                borderRadius : '0.3em'
            }}>Voir tout les animes</h3>
            </a>

            </div>
        </section>
        </>
    )
    }else if(props.search != ''){
        const loader_style = {
            position : 'absolute',
            display : 'flex',
            justifyContent : 'center',
            textAlign : 'center',
            top : '50%',
            left : '50%',
            translate : '-50% -50%'
        }
        return (
            <>
            <section>
                <Loader_1 style={loader_style}/>
            </section>
            </>
        )
    }
}