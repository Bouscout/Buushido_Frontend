// import './decor.css'

export function Nuage_1(props){
    return <div className='cloud-1' style={props.style ? props.style : null}/>
}
export function Nuage_2(props){
    return <div className='cloud-2' style={props.style ? props.style : null}/>
}
export function Nuage_3(props){
    return <div className='cloud-3' style={props.style ? props.style : null}/>
}
export function Nuage_4(props){
    return <div className='cloud-4' style={props.style ? props.style : null}/>
}
export function Nuage_5(props){
    return <div className='cloud-5' style={props.style ? props.style : null}/>
}
export function Nuage_6(props){
    return <div className='cloud-6' style={props.style ? props.style : null}/>
}
export function Nuage_7(props){
    return <div className='cloud-7' style={props.style ? props.style : null}/>
}
export function Nuage_8(props){
    return <div className='cloud-8' style={props.style ? props.style : null}/>
}
export function Nuage_9(props){
    return <div className='cloud-9' style={props.style ? props.style : null}/>
}
