// import './upper.css'

export default function Upper(){
    return (
    <section id='upper'>
    </section>
        )
}