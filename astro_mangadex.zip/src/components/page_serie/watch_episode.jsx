import { useEffect, useLayoutEffect, useState } from "react"
import Brief_visit  from "../self-contained/metrics/brief_visit"
//function for taking care of video displaying

export default function Watch_episode(props){
    //the id of the show
    const id = props.id

    // we will have an array with all the episodes of the actual saison 
    // flat it to avoid bugs with the page set up
    
    //we make a state with the actual episode
    const [actual, setActual] = useState(props.epi)
    const [lect, setLect] = useState(props.epi.url)

    //updating the episode in the in_watching list
    useEffect(()=>{

        // checking if the next episode is the last episode to remove the item from recently watch
        let liste = JSON.parse(localStorage.getItem('buushido_liste'))
        if((all_episodes.indexOf(actual) + 1) >= all_episodes.length - 1 && Array.isArray(liste)){
            //removing instance from local storage
            localStorage.removeItem('buushido_lastEpisode'+id)
            
            // removing it from the liste of last watched
            liste = liste.filter(v => v !== id )
            //update the list 
            localStorage.setItem('buushido_liste', JSON.stringify(liste))
        }else{
            
            // when it is not the last episode            
            // setting the session storage to remember last watched episode

            // checking if it is not the first episode
            
            let last_watch = [id, actual.saison, parseInt(actual.episode)]

            // in case we don't want to save if if first episode
            // if(parseInt(last_watch[1]) !==1 && last_watch !== 1 ){

            
            localStorage.setItem('buushido_lastEpisode'+id, JSON.stringify(last_watch))
            try{
                // in case the list exists but doesn't contain the element
                if (!liste.includes(id)){
                    liste.push(id)
                    localStorage.setItem('buushido_liste', JSON.stringify(liste))
                    
                }else{
                    // in case it includes it we want to move it to the front
                    let index = liste.indexOf(id)
                    liste.splice(index, 1) //removing element
                    
                    liste.push(id) // putting it to the front
                    
                    console.log('moved to the front : ', liste)
                    //saving changes
                    localStorage.setItem('buushido_liste', JSON.stringify(liste))
                }
                
            }catch(e){   // catching the error in case the list is not even created 
                liste = [id]
                localStorage.setItem('buushido_liste', JSON.stringify(liste))
                
            } 
        
            console.log('not the last episode')
        }
         
    }, [actual])
    
    let all_episodes
    if(props.epi.special_name){
        all_episodes = []
        all_episodes.length = 0
        actual.episode = 1
    }else{
        all_episodes = props.others.flat()
        // console.log('the last episode of the saison is : ', all_episodes.at(-1))
    }
    

    function next(){
        // making the report of presence
        Brief_visit()

       

        // we know that the episode number of actual we'll correspond to it's index -1 in the list so
        // by just changing the index to +1 we get the next
        let present = all_episodes[all_episodes.indexOf(actual) + 1]
        // let present = all_episodes[parseInt(actual.episode)]
        setActual(present)
        setLect(present.url)
        // setActual(all_episodes[parseInt(actual.episode)])
    }
    function precedent(){
        // reporting the presence
        Brief_visit()
                    
        // let present = all_episodes[parseInt(actual.episode) - 2]
        let present = all_episodes[all_episodes.indexOf(actual) - 1]
        setActual(present)
        setLect(present.url)
        // setActual(all_episodes[parseInt(actual.episode) - 2])
    }

    function change_lecteur(lien){
        setLect(lien)
    }

    return (
        <>
        <div id="watching">
            <h1 onClick={()=>{props.cancel(false)}} id="close"><i className="fa-regular fa-circle-xmark"></i>  Retour</h1>
        <div>
        <div style={{
            width : '91vw', aspectRatio : '16 / 9', margin : '0 auto', 
        }}>
        <iframe id="buushido_frame" src={lect} frameBorder={0} allowFullScreen />
        </div>

        <div style={{display : 'flex', justifyContent : 'space-between', height : '5vh',}}>

                    <div><a href="mailto:buushidobug1@gmail.com"><button><h1>Signaler bug</h1></button></a></div>
                   
                    <div style={{
                        display : 'flex', justifyContent : 'center',
                    }}>

                    {(all_episodes.indexOf(actual) - 1) < 0 ?  null : <button onClick={()=>{precedent()}}><h1>Precedent</h1></button>}
                    {/* {parseInt(actual.episode) -1 === 0 ?  null : <button onClick={()=>{precedent()}}><h1>Precedent</h1></button>} */}

                    {/* <button onClick={()=>{window.open(lect, '_blank')}}><h1>Forcer Play</h1></button> */}

                    {(all_episodes.indexOf(actual) + 1) >= all_episodes.length ? null : <button onClick={()=>{next()}}><h1>Prochain</h1></button>}
                    {/* {parseInt(actual.episode) >= all_episodes.length ? null : <button onClick={()=>{next()}}><h1>Prochain</h1></button>} */}

                    {/* setting up the other lecteurs */}
                    </div>

                    
                    <div style={{
                        display : 'flex', justifyContent : 'center',
                    }}>
                        {/* <button onClick={()=>{change_lecteur(actual.url)}}><h1>Lecteur 1</h1></button> */}
                        <Lecteur serie={actual} swap={change_lecteur}/>
                        {/* <button onClick={()=>{change_lecteur(actual.url2)}}><h1>Lecteur 2</h1></button>
                        {actual.url3 ? <button onClick={()=>{change_lecteur(actual.url3)}}>Lecteur 3</button> : null} */}
                    </div>
        </div>
        </div>
        <h2 style={{
            textAlign : 'center', color :'#fff'
        }}> saison {actual.saison} episode {actual.episode}</h2>


        <h1 style={{
            fontSize : '9vmin', color : '#f8a100', lineHeight : '130%', textAlign : 'center', marginTop : '30px'
        }}>Comments will be here when finished ⌚</h1>

        </div>

        </>
    
    )
}

function Lecteur(props){
    let serie = props.serie
    const choixx = [serie.url]
    if (serie.url2){
        choixx.push(serie.url2)
    }if(serie.url3){
        choixx.push(serie.url3)
    }

    function change_lect(evt){
        let lien = evt.target.value
        props.swap(lien)
    }

    return (
        <>
        <div id="buush">
        <label htmlFor="lecteur_buushido">Lecteur <i className="fa-solid fa-chevron-down"></i></label>
        <select name="lecteur_buushido" onChange={(e)=>{change_lect(e)}}>
        {choixx.map((lien, i)=>{
            return(
                <option key={i} value={lien} >{i+1}</option>
                )
            })}
        </select>
            </div>
        </>
    )
}